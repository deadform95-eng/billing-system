# pulsenet-admin-vercel

PulseNet Admin Dashboard — standalone Vite + React SPA, extracted from the
`pulsenet` monorepo (`artifacts/admin`) so it can be deployed to Vercel on
its own, independent of the backend and of the customer portal.

Includes: authentication (login/2FA/forgot & reset password/register),
dashboard, customers, customer detail, subscriptions, invoices, plans,
vouchers, routers, MikroTik monitor, RADIUS, users, notifications, settings
(tenant/payment methods/loyalty/NOC/notifications panels), the AI NOC view
(traffic/logs/AI analyst), pending approvals, and the first-run setup
wizard.

## What changed vs. the monorepo copy

This app talked to the backend and to a sibling workspace package
(`@workspace/api-client-react`) using pnpm workspace resolution, which only
works inside the original monorepo. To make this folder deployable on its
own:

1. **`@workspace/api-client-react` is vendored in**, unchanged, at
   `src/lib/api-client/` (it was already dependency-free — it only used
   `@tanstack/react-query` and its own sibling files — so this was a
   straight copy, not a rewrite). Every `@workspace/api-client-react` import
   across the app was rewritten to `@/lib/api-client`.
2. **`main.tsx` now calls `setBaseUrl(import.meta.env.VITE_API_BASE_URL)`**
   at startup. The generated API client already supported a configurable
   base URL (`getBaseUrl()`/`setBaseUrl()`), it just was never wired up
   because backend and frontend previously shared an origin. Set
   `VITE_API_BASE_URL` to your deployed `pulsenet-api` URL — see
   `.env.example`.
3. **`vite.config.ts`** no longer requires the Replit-only `PORT` /
   `BASE_PATH` / `REPL_ID` env vars (they threw if unset, which would have
   failed every Vercel build). Also dropped the `@replit/vite-plugin-*`
   dev-only plugins (cartographer, dev banner, runtime error overlay) and
   the unused `@assets` alias — none of that is needed outside the Replit
   editor, and no source file referenced `@assets`.
4. **`tsconfig.json`** no longer extends `../../tsconfig.base.json` or
   references `../../lib/api-client-react` (both monorepo-only paths); the
   handful of compiler options actually used were inlined.
5. **`package.json`**: `catalog:` version references (a pnpm-workspace
   feature) were resolved to the pinned versions from the monorepo's
   `pnpm-workspace.yaml`, and `@workspace/api-client-react: workspace:*` was
   dropped (superseded by step 1).
6. No `tailwind.config.*` is included because this project uses Tailwind v4
   (`@tailwindcss/vite` + CSS `@theme`), which doesn't use a JS config file
   — all theme tokens live in `src/index.css`. This matches the source app.

Nothing in `src/pages`, `src/components`, `src/hooks`, or business logic was
changed.

## Install & build (verified)

```bash
npm install
npm run build      # -> dist/
npm run typecheck  # optional; see note below
```

`npm run build` (Vite) was run end-to-end during extraction and produces
`dist/index.html` + hashed assets. Vite does not type-check, so
`npm run typecheck` is a separate, stricter script; it surfaces a few
pre-existing type mismatches between hand-written pages and the orval-
generated API types (e.g. `customer-detail.tsx` passing `string | null`
where the generated `CustomerUpdate` type expects `string | undefined`, and
`vouchers.tsx` referencing a `routerId` field not present on the generated
`VoucherBatchInput`). These exist in the original monorepo source too — they
predate this extraction and don't block `vite build`.

## Environment variables

See `.env.example`. In Vercel: Project Settings → Environment Variables.

| Variable | Required | Description |
|---|---|---|
| `VITE_API_BASE_URL` | Recommended | Base URL of the deployed `pulsenet-api` backend, e.g. `https://api.pulsenet.example.co.ke`. Omit only if this app and the API share an origin via a reverse proxy. |

## Deploying to Vercel

1. Push this folder to its own git repo (or use Vercel's "root directory"
   setting if keeping it in a subfolder of a larger repo).
2. Import it in Vercel → Framework Preset: **Vite**.
3. Build command: `npm run build` (already set in `vercel.json`). Output
   directory: `dist` (already set).
4. Add `VITE_API_BASE_URL` in Environment Variables.
5. On the backend (`pulsenet-api`), add this Vercel deployment's URL to
   `CORS_ORIGINS` so the browser can call the API cross-origin with
   credentials.
6. Deploy.

`vercel.json` includes a catch-all rewrite to `index.html` so client-side
routing (via `wouter`) works on hard refresh / deep links.

## Known blockers / follow-ups

- **No original lockfile shipped** with the source monorepo (no
  `pnpm-lock.yaml`), so this project's `package-lock.json` was generated
  fresh from the declared version ranges rather than reproducing exact
  original versions. Recommend running your own `npm install` and reviewing
  `npm audit` before first production deploy.
- The pre-existing type mismatches noted above are cosmetic (they don't
  affect the built bundle) but worth fixing upstream.
